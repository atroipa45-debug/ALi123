# Super JinX host guard (every 20s)
# 1) Locked inbound: every route is forced and reverted within 20s if anyone edits it
# 2) Other inbounds: get the same full route set automatically and are kept in sync,
#    as long as they still look like ours. Rename a host in the panel and the guard leaves it alone.
# Every config name starts with the locked brand name, then shows its route and protocol, e.g.
#   جینکس | 𝗝𝗶𝗻𝗫 ✦ 🚀 Turbo Iran · VLESS      (the apps still pick the fastest one with their ping test)
import json, os, time, urllib.error, urllib.request, urllib.parse

API = "http://127.0.0.1:8000"
LOCKED_TAG = json.load(open("/opt/locked_inbound.json"))["tag"]
LOCKED_REMARK = "جینکس | 𝗝𝗶𝗻𝗫"                    # every config name starts with this
OLD_REMARKS = ("جینکس | 𝙎𝙪𝙥𝙚𝙧 𝗝𝗶𝗻𝗫",)               # names of the previous version -> renamed automatically
DOMAIN = os.environ.get("PANEL_DOMAIN") or os.environ.get("RAILWAY_PUBLIC_DOMAIN", "")
CF_HOST = os.environ.get("CF_TUNNEL_HOSTNAME", "") if os.environ.get("CF_TUNNEL_TOKEN") else ""
def _list(name, default=""):
    return [x.strip() for x in os.environ.get(name, default).replace(" ", ",").split(",") if x.strip()]

CF_IPS = _list("CF_CLEAN_IP")                        # one or more Cloudflare clean IPs (best one per operator)
# Cloudflare HTTPS ports: different operators throttle different ports, so every clean IP is offered on each
CF_PORTS = [int(p) for p in _list("CF_PORTS", "443,2053,8443") if p.isdigit() and int(p) in (443, 2053, 2083, 2087, 2096, 8443)] or [443]
RELAY_IPS = _list("IRAN_RELAY_IP")                   # optional Iranian relay server(s), see iran-relay.sh
try:
    RELAY_PORT = int(os.environ.get("IRAN_RELAY_PORT", "443") or 443)
    assert 1 <= RELAY_PORT <= 65535
except Exception:
    print("[guard] WARNING: IRAN_RELAY_PORT is not a valid port -> using 443", flush=True); RELAY_PORT = 443
FRAG = os.environ.get("JINX_FRAGMENT", "10-20,10-20,tlshello").strip()   # "" disables the fragment route
PATHS = {LOCKED_TAG: "/panel-ws?ed=2048", "VLESS WS": "/vless?ed=2048", "VMESS WS": "/vmess?ed=2048",
         "TROJAN WS": "/trojan?ed=2048", "VLESS HTTPUPGRADE": "/vhu?ed=2048", "VLESS XHTTP": "/vxh"}
# 🛰 Reality over a Railway TCP Proxy (only when TCP Proxy is on; see lock.py)
REALITY_TAG = "VLESS REALITY"
TCP_DOMAIN = os.environ.get("RAILWAY_TCP_PROXY_DOMAIN", "").strip()
try:
    TCP_PORT = int(os.environ.get("RAILWAY_TCP_PROXY_PORT") or 0)
except ValueError:
    TCP_PORT = 0
REALITY_SNI = (os.environ.get("JINX_REALITY_SNI") or "www.speedtest.net").strip()
if TCP_DOMAIN and TCP_PORT and os.environ.get("JINX_REALITY", "1") != "0":
    PATHS[REALITY_TAG] = ""
PROTO = {REALITY_TAG: "Reality", LOCKED_TAG: "JinX Core", "VLESS WS": "VLESS", "VMESS WS": "VMess", "TROJAN WS": "Trojan", "VLESS HTTPUPGRADE": "HTTPUpgrade", "VLESS XHTTP": "XHTTP"}
# route names (each config gets its own name; the apps still pick the fastest one with their ping test)
R_RELAY, R_CDN_IP, R_CDN = "🚀 Turbo Iran", "🌩 Cloud Storm", "☁️ Cloud Shield"
# Railway region of this service (works in all 4; Amsterdam = lowest ping from Iran)
_REG = (os.environ.get("RAILWAY_REPLICA_REGION") or os.environ.get("JINX_REGION") or "europe-west4").lower()
REGION = ("🇺🇸 Virginia" if "us-east" in _REG else "🇺🇸 California" if "us-west" in _REG else
          "🇸🇬 Singapore" if "asia" in _REG or "southeast" in _REG else "🇳🇱 Amsterdam")
# two fragment profiles: strong (SNI-filtered operators) and light (almost no speed cost)
FRAG_LIGHT = os.environ.get("JINX_FRAGMENT_LIGHT", "100-200,1-3,tlshello").strip()
# ⚡ 12 direct methods, each one different (transport x TLS fingerprint x ALPN x fragment) -> one of them always flies
#    WebSocket / HTTPUpgrade connections stay open forever on Railway (steadiest); XHTTP uses HTTP/2 multiplexing
#    (fastest to open new connections) but Railway caps one HTTP request at 15 min, so it gets only 2 of the 12
#    (inbound, name, fingerprint, alpn, fragment profile)
METHODS = [
    (None,                "🚀 Rocket",          "chrome",     "http/1.1", ""),        # 1  locked JinX Core
    (None,                "👻 Ghost Anti-Filter", "chrome",   "http/1.1", "strong"),  # 2
    ("VLESS WS",          "💫 Hyper Drive",     "firefox",    "http/1.1", ""),        # 3
    ("VLESS WS",          "🌪 Swift Shield",    "chrome",     "http/1.1", "light"),   # 4
    ("VMESS WS",          "🌀 Vortex",          "safari",     "http/1.1", ""),        # 5
    ("TROJAN WS",         "🔱 Trident",         "edge",       "http/1.1", ""),        # 6
    ("TROJAN WS",         "🥷 Ninja Stealth",   "randomized", "http/1.1", "strong"),  # 7
    ("VLESS HTTPUPGRADE", "⚡ Lightning",       "chrome",     "http/1.1", ""),        # 8
    ("VLESS HTTPUPGRADE", "🌠 Meteor",          "ios",        "http/1.1", "light"),   # 9
    ("VLESS XHTTP",       "🛸 Warp Speed",      "chrome",     "h2,http/1.1", ""),     # 10
    ("VLESS HTTPUPGRADE", "🌌 Nebula",          "firefox",    "http/1.1", ""),        # 11 (upgrade = no 15-min cap on Railway)
    ("VLESS XHTTP",       "🧬 Quantum",         "randomized", "h2,http/1.1", "light"),# 12
]
# when this image has no HTTPUpgrade / XHTTP, the same number of configs is kept with these on WebSocket
FILL = [("VLESS WS", "🌠 Meteor", "ios", "light"), ("VMESS WS", "🛸 Warp Speed", "chrome", ""), ("TROJAN WS", "🌌 Nebula", "firefox", ""),
        ("VLESS WS", "🧬 Quantum", "randomized", "light"), ("VMESS WS", "⚡ Lightning", "edge", "strong")]
# 🔁 Mux (only in apps that get the full Xray JSON: v2rayNG, v2rayN, Streisand, Happ; sing-box / Clash ignore it):
#    new connections reuse an open tunnel -> no new handshake to Amsterdam -> pages and the in-app test answer faster.
#    The other half stays without Mux for the highest single-download speed.
MUX_ON = os.environ.get("JINX_MUX", "1") != "0"
# the fastest picks (Rocket, Lightning, Vortex, Warp Speed) stay WITHOUT Mux: one tunnel per connection = full download speed
MUX = {"💫 Hyper Drive", "🔱 Trident", "🌌 Nebula", "🛰 Reality Pulse"}
SAFE_FP = False                                     # True after the panel refused a fingerprint value
AVAILABLE = set()                                   # inbound tags this panel really has (filled from the panel every round)
OLD_AUTO = {"𝗝𝗶𝗻𝗫 | VLESS", "𝗝𝗶𝗻𝗫 | VMess", "𝗝𝗶𝗻𝗫 | Trojan"}      # names of older versions -> renamed

# 🌐 mirrors: more Railway domains for the same service (Settings > Domains). If an operator or a city ever blocks
#    one domain name, the same server is still reachable through the others -> nothing goes down.
_RW = os.environ.get("RAILWAY_PUBLIC_DOMAIN", "").strip()
MIRRORS = [d for d in dict.fromkeys(_list("JINX_EXTRA_DOMAINS") + ([_RW] if _RW and DOMAIN and _RW != DOMAIN else []))
           if d and d != DOMAIN and "." in d]
HAS_RAILWAY_DOMAIN = bool(DOMAIN)
if not DOMAIN and CF_HOST:
    DOMAIN = CF_HOST  # tunnel-only setup: everything goes through the tunnel hostname

def name(route, tag):
    return f"{LOCKED_REMARK} ✦ {route} · {PROTO.get(tag, 'JinX')}"

def base(path, address=None, sni=None, port=443, frag="", alpn="http/1.1", remark=LOCKED_REMARK, fp="chrome", mux=False):
    sni = sni or DOMAIN
    return {"remark": remark, "path": path, "address": address or sni, "port": port, "sni": sni, "host": sni,
            "security": "tls", "alpn": alpn, "fingerprint": "chrome" if SAFE_FP else fp,
            "allowinsecure": False, "is_disabled": False, "mux_enable": bool(mux and MUX_ON),
            "fragment_setting": frag or None}   # explicit, so no config ever inherits a fragment by accident

def reality_hosts():
    out = []
    for label, fp in (("🛰 Reality Pulse", "chrome"), ("🌑 Dark Matter", "firefox")):
        out.append({"remark": name(label, REALITY_TAG), "address": TCP_DOMAIN, "port": TCP_PORT, "sni": REALITY_SNI, "host": "",
                    "path": "", "security": "inbound_default", "alpn": "", "fingerprint": "chrome" if SAFE_FP else fp,
                    "allowinsecure": False, "is_disabled": False, "mux_enable": bool(label in MUX and MUX_ON), "fragment_setting": None})
    return out

def wanted(tag):
    """All routes for one inbound, best first (MCI / Irancell / TCI / Rightel each have a winner)."""
    if tag == REALITY_TAG:
        return reality_hosts() if REALITY_TAG in PATHS else []
    path = PATHS.get(tag)
    if not path:
        return []
    alpn = "h2,http/1.1" if tag == "VLESS XHTTP" else "http/1.1"
    out = []
    n = lambda r: name(r, tag)
    if HAS_RAILWAY_DOMAIN and tag in tunnel_tags():
        for k, ip in enumerate(RELAY_IPS):                             # 🇮🇷 Iran relay = lowest ping
            out.append(base(path, address=ip, port=RELAY_PORT, alpn=alpn, remark=n(R_RELAY + (f" {k + 1}" if len(RELAY_IPS) > 1 else ""))))
    if CF_HOST and tag in tunnel_tags():
        for k, ip in enumerate(CF_IPS):                                # ☁️ Cloudflare clean IPs x ports
            for p in CF_PORTS:
                out.append(base(path, address=ip, sni=CF_HOST, port=p, alpn=alpn, remark=n(f"{R_CDN_IP} {p}" + (f" #{k + 1}" if len(CF_IPS) > 1 else ""))))
        out.append(base(path, address=CF_HOST, sni=CF_HOST, alpn=alpn, remark=n(R_CDN)))  # ☁️ Cloudflare by hostname
    if HAS_RAILWAY_DOMAIN:
        out.extend(direct(tag, path))                               # ⚡ straight to Railway: the 12 methods
        if tag in tunnel_tags():
            for k, d in enumerate(MIRRORS):                        # 🌐 same server, other domain names
                out.append(base(path, address=d, sni=d, alpn=alpn, mux=True, remark=n(f"🌐 Mirror {k + 1}")))
    return out

def tunnel_tags():
    """relay / Cloudflare routes go on the 2 strongest transports only (JinX Core + the fastest one this image has),
       so the list stays short (HTTPUpgrade first: never cut by Railway)"""
    if not HAS_RAILWAY_DOMAIN:
        return set(PATHS)              # tunnel-only setup: the tunnel is the only way in, so every transport gets it
    fast = next((t for t in ("VLESS HTTPUPGRADE", "VLESS XHTTP", "VLESS WS") if not AVAILABLE or t in AVAILABLE), "VLESS WS")
    return {LOCKED_TAG, fast}

def frag_of(profile):
    if not FRAG or not profile:
        return ""
    return FRAG if profile == "strong" else (FRAG_LIGHT or FRAG)

def direct(tag, path):
    """this inbound's share of the 12 direct methods (missing HU / XHTTP inbounds are replaced, the count stays 12)"""
    out, seen = [], set()
    plan = [(m[0] or LOCKED_TAG, m[1], m[2], m[3], m[4]) for m in METHODS]
    missing = [p for p in plan if p[0] not in AVAILABLE] if AVAILABLE else []
    plan = [p for p in plan if not AVAILABLE or p[0] in AVAILABLE] + [(f[0], f[1], f[2], "http/1.1", f[3]) for f in FILL[:len(missing)] if f[0] in AVAILABLE]
    for t, label, fp, alpn, prof in plan:
        if t != tag or label in seen:
            continue
        seen.add(label)
        mux = label in MUX and t != "VLESS XHTTP"          # XHTTP has its own multiplexing
        if label == "🚀 Rocket":
            label = REGION + " Rocket"
        out.append(base(path, frag=frag_of(prof), alpn=alpn, fp=fp, remark=name(label, tag), mux=mux))
    return out

CORE = ("remark", "address", "port", "sni", "host", "path", "security", "alpn", "fingerprint")

def same(cur, want):
    # core fields must match; extra fields only if this Marzban version has them (no endless re-writes)
    return all(cur.get(k) == v for k, v in want.items() if k in CORE or k in cur)

def is_default(h):
    return (not h) or "{SERVER_IP}" in str(h.get("address", ""))

def ours(tag, lst):
    """Still managed by us: every host has our name (or an old auto name) and our path."""
    p = (PATHS.get(tag) or "").split("?")[0]
    pre = tuple(r + " ✦ " for r in (LOCKED_REMARK,) + OLD_REMARKS)
    return bool(lst) and all((h.get("remark") in OLD_AUTO | {LOCKED_REMARK} | set(OLD_REMARKS) or str(h.get("remark") or "").startswith(pre)) and str(h.get("path") or "").split("?")[0] == p for h in lst)

def req(method, path, data=None, token=None, form=False):
    h = {}
    if token:
        h["Authorization"] = "Bearer " + token
    if data is not None:
        if form:
            data = urllib.parse.urlencode(data).encode()
            h["Content-Type"] = "application/x-www-form-urlencoded"
        else:
            data = json.dumps(data).encode()
            h["Content-Type"] = "application/json"
    r = urllib.request.Request(API + path, data=data, headers=h, method=method)
    return json.loads(urllib.request.urlopen(r, timeout=10).read() or b"null")

def sync(hosts, tag):
    want = wanted(tag)
    cur = hosts.get(tag) or []
    if not want or (len(cur) == len(want) and all(same(c, w) for c, w in zip(cur, want))):
        return False
    tmpl = cur[0] if cur else {}
    new = []
    for w in want:
        h = dict(tmpl); h.update(w); new.append(h)
    hosts[tag] = new
    return True

if not DOMAIN:
    print("[guard] WARNING: no domain yet. Generate a Railway domain (port 8080) and redeploy.", flush=True)
else:
    print(f"[guard] region {REGION} | 12 direct methods | tunnel routes on 2 transports: "
          f"relay {len(RELAY_IPS)}, cf ips {len(CF_IPS)} x ports {CF_PORTS if CF_HOST else []}, cf domain {int(bool(CF_HOST))}"
          f" | fragment {'on' if FRAG else 'off'}", flush=True)

while True:
    try:
        cred = json.load(open("/run/jinx/system.json"))
        tok = req("POST", "/api/admin/token", cred, form=True)["access_token"]
        hosts = req("GET", "/api/hosts", token=tok)
        AVAILABLE = {t for t in hosts if t in PATHS}
        changed = False
        if DOMAIN:
            for tag, lst in hosts.items():
                if tag == LOCKED_TAG or is_default(lst[0] if lst else None) and all(is_default(h) for h in lst) or ours(tag, lst):
                    if sync(hosts, tag):
                        changed = True
                        print(f"[guard] {'locked inbound restored' if tag == LOCKED_TAG else 'routes updated for ' + tag}", flush=True)
            if LOCKED_TAG not in hosts:
                print("[guard] locked inbound not loaded yet", flush=True)
        if changed:
            try:
                req("PUT", "/api/hosts", hosts, token=tok)
            except urllib.error.HTTPError as he:
                if he.code in (400, 422):
                    # this Marzban version rejected a fragment / fingerprint value -> plain chrome + no fragment,
                    # every config keeps working (and keeps its own name)
                    print(f"[guard] panel rejected a fragment/fingerprint value ({he.code}), retrying with safe values", flush=True)
                    FRAG = ""; SAFE_FP = True
                    for tag in list(hosts):
                        if tag == LOCKED_TAG or ours(tag, hosts[tag]):
                            for h in hosts[tag]:
                                h["fragment_setting"] = None; h["fingerprint"] = "chrome"
                    req("PUT", "/api/hosts", hosts, token=tok)
                else:
                    raise
    except Exception as e:
        print("[guard] waiting for panel:", e, flush=True)
    time.sleep(20)
